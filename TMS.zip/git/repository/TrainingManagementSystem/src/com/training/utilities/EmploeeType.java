package com.training.utilities;

public class EmploeeType {

}
