package com.training.dao;

public class ManagerDAOImpl {

}
