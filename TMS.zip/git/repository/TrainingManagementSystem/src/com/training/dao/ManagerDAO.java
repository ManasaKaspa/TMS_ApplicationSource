package com.training.dao;

public interface ManagerDAO {

}
