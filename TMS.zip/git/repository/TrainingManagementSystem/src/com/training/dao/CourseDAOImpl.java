package com.training.dao;

public class CourseDAOImpl {

}
