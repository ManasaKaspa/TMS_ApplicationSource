package com.training.view;

public class ErrorView {

}
