package com.training.view;

public class AdminView {

}
