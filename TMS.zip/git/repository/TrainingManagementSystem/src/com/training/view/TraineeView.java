package com.training.view;

public class TraineeView {

}
