package com.training.ui;

public class ConsoleUI {

}
