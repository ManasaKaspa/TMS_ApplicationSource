package com.training.service;

public interface TraineeService {

}
