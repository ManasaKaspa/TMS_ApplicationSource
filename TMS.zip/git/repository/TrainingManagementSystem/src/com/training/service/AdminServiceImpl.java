package com.training.service;

public class AdminServiceImpl {

}
