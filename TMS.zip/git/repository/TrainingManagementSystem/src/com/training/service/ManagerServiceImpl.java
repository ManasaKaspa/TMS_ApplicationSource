package com.training.service;

public class ManagerServiceImpl {

}
