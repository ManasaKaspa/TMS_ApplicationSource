package com.training.service;

public interface AdminService {

}
