package com.training.controller;

public class FrontController {

}
