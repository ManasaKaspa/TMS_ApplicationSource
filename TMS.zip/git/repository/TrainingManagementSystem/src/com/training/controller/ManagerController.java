package com.training.controller;

public class ManagerController {

}
