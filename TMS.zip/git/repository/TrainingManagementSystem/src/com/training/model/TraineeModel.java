package com.training.model;

public class TraineeModel {

}
