package com.training.model;

public class EmployeeModel {

}
