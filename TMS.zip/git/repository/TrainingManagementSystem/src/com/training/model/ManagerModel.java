package com.training.model;

public class ManagerModel {

}
