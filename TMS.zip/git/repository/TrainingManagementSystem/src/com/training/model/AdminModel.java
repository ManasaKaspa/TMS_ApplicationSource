package com.training.model;

public class AdminModel {

}
