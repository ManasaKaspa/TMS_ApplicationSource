package com.training.entities;

public class Manager {

}
